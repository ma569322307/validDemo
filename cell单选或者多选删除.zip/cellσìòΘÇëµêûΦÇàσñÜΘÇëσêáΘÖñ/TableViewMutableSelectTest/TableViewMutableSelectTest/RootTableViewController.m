//
//  RootTableViewController.m
//  TableViewMutableSelectTest
//
//  Created by syq on 15/11/4.
//  Copyright © 2015年 syq. All rights reserved.
//

#import "RootTableViewController.h"

@interface RootTableViewController ()


@property (nonatomic, strong)NSMutableArray *dataArr;

@end

@implementation RootTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.dataArr = [NSMutableArray arrayWithObjects:@"第1条",@"第2条",@"第3条",@"第4条",@"第5条",@"第6条",@"第7条",@"第8条",@"第9条",@"第10条",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",nil];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
//    self.tableView.editing = YES;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(0, 0, 100, 30);
    [button setTitle:@"点编辑后全选" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(chooseAllCell) forControlEvents:UIControlEventTouchUpInside];
    self.tableView.tableHeaderView = button;
    
}
-(void)chooseAllCell{
    
//    NSArray *arr = [self.tableView indexPathsForVisibleRows];
    //找到所有的indexPath
     NSArray *arr = [self.tableView indexPathsForRowsInRect:CGRectMake(0, 0, self.view.frame.size.width, self.tableView.contentSize.height)];
    
    [arr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        [self.tableView selectRowAtIndexPath:obj animated:YES scrollPosition:UITableViewScrollPositionNone];

    }];
}
-(IBAction)shureAction:(id)sender{
    //拿到现在是选择状态的indexP数组。。
    /*
     **这个属性方便了太多！
     */
    NSArray *arr = self.tableView.indexPathsForSelectedRows;
    //此处从数组删除注意：按照arr 顺序删除会造成越界崩溃、、
    
    NSMutableIndexSet *set = [NSMutableIndexSet indexSet];
    for (NSIndexPath *indexP in arr) {
        [set addIndex:indexP.row];
    }

    
    [self.dataArr removeObjectsAtIndexes:set];
    
    
    
    [self.tableView deleteRowsAtIndexPaths:arr withRowAnimation:UITableViewRowAnimationAutomatic];

//    [self.tableView reloadData];
    
    
    NSLog(@"seleteArr = %@",arr);
    
}
-(IBAction)deleteAction:(id)sender{
//    self.tableView.allowsMultipleSelection = YES;
    [self.tableView setEditing:!self.tableView.editing animated:YES];
//    sender
    
    self.navigationItem.rightBarButtonItem.title = self.tableView.editing ? @"取消":@"编辑";

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArr.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    cell.textLabel.text = self.dataArr[indexPath.row];
    
    // Configure the cell...
    
    return cell;
}



// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    //实现编辑状态多选
    if (self.tableView.editing) {
        return UITableViewCellEditingStyleInsert|UITableViewCellEditingStyleDelete;
    }
    //普通状态左滑删除
    else{
        return UITableViewCellEditingStyleDelete;
    }
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [self.dataArr removeObjectAtIndex:indexPath.row];
        [self.tableView beginUpdates];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [self.tableView endUpdates];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
